# DonationDash
Developed Android Application Using Flutter`
  <br />
    `which can use for to Give donation with net banking and cards etc.`
   <br />
  `User can see location of donation centers in map and App is implemented`<br />
   `to donate for education, food, clothes ,old age home, sanitizer and  mask and etc.`

